# Langkah Menjalankan (strukdat8)

```bash
uv init strukdat8
cd strukdat8
uv add pandas streamlit openpyxl matplotlib
# salin main.py dan penjualan.xlsx ke folder project ini (timpa main.py bawaan uv)
uv run streamlit run main.py
```

Lalu unggah `penjualan.xlsx` di halaman web yang terbuka.
